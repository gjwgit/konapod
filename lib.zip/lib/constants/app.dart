/// A Bluelink app for Hyundai
///
// Time-stamp: <Monday 2026-03-16 22:01:12 +1100 Graham Williams>
///
/// Copyright (C) 2026, Togaware Pty Ltd
///
/// Licensed under the GNU General Public License, Version 3 (the "License");
///
/// License: https://opensource.org/license/gpl-3-0
//
// This program is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation, either version 3 of the License, or (at your option) any later
// version.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
// details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <https://opensource.org/license/gpl-3-0>.
///
/// Authors: Claude, Graham Williams

/// App-wide constants.
library;

const String appName = 'Kona Pod - Capture and Store Vehicle Stats';
const String appVersion = '1.0.0';
const String appDescription =
    'Hyundai Bluelink vehicle dashboard with Solid Pod integration.';
const String appDirectory = 'konapod';
const String podStatusPath = 'konapod/';
const String statusFilePrefix = 'status_';
const String statusFileSuffix = '.ttl';
